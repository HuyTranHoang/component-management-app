create function increase_stock_quantity() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE products
    SET stock_quantity = stock_quantity + NEW.import_quantity
    WHERE id = NEW.product_id;

    RETURN NEW;
END;
$$;

alter function increase_stock_quantity() owner to postgres;

