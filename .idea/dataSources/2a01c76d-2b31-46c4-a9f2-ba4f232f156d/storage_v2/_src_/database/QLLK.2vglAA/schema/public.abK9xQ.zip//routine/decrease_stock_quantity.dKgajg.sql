create function decrease_stock_quantity() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE products
    SET stock_quantity = stock_quantity - NEW.export_quantity
    WHERE id = NEW.product_id;

    RETURN NEW;
END;
$$;

alter function decrease_stock_quantity() owner to postgres;

